import flask 
from flask import request

app = flask.Flask(__name__)

@app.route('/demo', methods=['GET'])
def demo():
    request_action = request.args['action']

    if request_action == "obter_nome_aluno":
        msg = "João"
    elif request_action == "obter_responsavel":
        try:
            request_aluno = request.args['aluno']
            request_aluno_lower = request.args['aluno'].lower()
        except:
            request_aluno = ""

        if request_aluno_lower == 'joão' or request_aluno_lower == 'joao':
            msg =  "O responsável do João Sousa é a mãe Maria Sousa"
        elif request_aluno_lower == 'júlia' or request_aluno_lower == 'julia':
            msg = "O responsável da Júlia Neves é o pai Rui Neves"
        else:
            msg = "Lamento, mas o aluno '"  + request_aluno + "' não existe"
    elif request_action == "consultar_horario_retirada":
        try:
            request_periodo = request.args['periodo']
        except:
            request_periodo = ""

        if request_periodo == 'parcial':
            msg = "A saída do periodo parcial é às 14h00"
        elif request_periodo == 'integral':
            msg = "A saída do periodo integral é às 18h00"
        else:
            msg = "Lamento, mas não percebi qual o periodo pretendido"
    
    print (msg)

    return msg

