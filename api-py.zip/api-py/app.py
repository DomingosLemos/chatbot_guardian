import flask 
from flask import request

app = flask.Flask(__name__)

@app.route('/demo', methods=['GET'])
def demo():
    request_action = request.args['action']
    try:
        request_aluno = request.args['aluno']
        request_aluno_lower = request.args['aluno'].lower()
    except:
        request_aluno = ""

    if request_action == "obter_nome_aluno":
        msg = "João"
    elif request_action == "obter_responsavel":
        if request_aluno_lower == 'joão':
            msg =  "O responsável do João Sousa é a mãe Maria Sousa"
        elif request_aluno_lower == 'júlia':
            msg = "O responsável da Júlia Neves é o pai Rui Neves"
        else:
            msg = "Lamento, mas o aluno '"  + request_aluno + "' não existe"

    print (msg)

    return msg
